//Author(s): Shelby Jordan
package threesolid;

public interface IDirect {
	public void setWorker(IWorker w);
}
