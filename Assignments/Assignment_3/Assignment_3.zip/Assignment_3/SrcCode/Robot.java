//Authors: Shelby Jordan, Sam Pugh
package threesolid;

public class Robot implements IWork {

	@Override
	public void work() {
		// TODO Auto-generated method stub

	}

}
