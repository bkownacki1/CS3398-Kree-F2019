//Authors: Shelby Jordan, Sam Pugh
package threesolid;

public interface IWorker extends IEat, IWork {
}
