//Authors: Shelby Jordan, Sam Pugh
package threesolid;

public class Worker implements IWork, IEat {

	@Override
	public void eat() {
		// TODO Auto-generated method stub

	}

	@Override
	public void work() {
		// TODO Auto-generated method stub

	}

}
