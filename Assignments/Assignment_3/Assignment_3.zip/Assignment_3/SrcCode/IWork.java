//Authors: Shelby Jordan, Sam Pugh
package threesolid;

public interface IWork {
	public void work();
}
