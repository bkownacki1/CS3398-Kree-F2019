//Authors: Shelby Jordan, Sam Pugh
package threesolid;

public interface IEat {
	public void eat();
}
