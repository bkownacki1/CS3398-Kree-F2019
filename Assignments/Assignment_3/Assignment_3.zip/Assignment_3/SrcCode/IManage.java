//Author(s): Shelby Jordan
package threesolid;

public interface IManage extends IDirect {
	public void manage();
}
