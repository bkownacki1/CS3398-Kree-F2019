package intro;

import java.text.SimpleDateFormat;
import java.util.Date;


public class HelloWorld {

	public static void main(String[] args) {
		SimpleDateFormat date_format = new SimpleDateFormat("dd/MM/yyy HH:mm:ss");
		Date the_date = new Date();
		
		System.out.println("The current date is: " + date_format.format(the_date));
		
		Greeter greeter = new Greeter();
		System.out.println(greeter.sayHello());
	}

}
