/**
 * 
 */
package intro;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestGreeter {

	/**
	 * @throws java.lang.Exception
	 * The first test conducted
	 */
	@BeforeEach
	void setUp() throws Exception {
		g = new Greeter();
	}

	/**
	 * @throws java.lang.Exception
	 * The last test conducted
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link intro.Greeter#Greeter()}.
	 */
	@Test
	void testGreeter() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link intro.Greeter#getName()}.
	 */
	@Test
	void testGetName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link intro.Greeter#setName(java.lang.String)}.
	 */
	@Test
	void testSetName() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link intro.Greeter#sayHello()}.
	 */
	@Test
	void testSayHello() {
		fail("Not yet implemented");
	}

}
