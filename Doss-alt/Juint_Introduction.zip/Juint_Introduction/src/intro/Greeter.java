package intro;

public class Greeter {
	public Greeter() {
		setName("");
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return hello message
	 */
	public String sayHello() {
		if(name == "") return "Hello";
		else return "Hello " + name + "!";
	}

	private String name;
	
}
