package test;

import static org.junit.Assert.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import intro.Greeter;

class TestGreeter {

	/**
	 * @throws java.lang.Exception
	 * Always the first test conducted
	 */
	@BeforeEach
	void setUp() throws Exception {
		g = new Greeter();
	}

	/**
	 * Test method for {@link intro.Greeter#getName()}.
	 */
	@Test
	void testGetName() {
		g.setName("Leroy");
		assertEquals(g.getName(),"Leroy");
	}

	/**
	 * Test method for {@link intro.Greeter#setName(java.lang.String)}.
	 */
	@Test
	void testSetName() {
		g.setName("TEST");
	    assertEquals(g.sayHello(),"Hello TEST!");
	    g.setName("New name");
	    assertEquals(g.sayHello(), "Hello New name!");
	}

	/**
	 * Test method for {@link intro.Greeter#sayHello()}.
	 */
	@Test
	void testSayHello() {
		g.setName("Nurse");
		assertEquals(g.sayHello(), "Hello Nurse!");
	}
	
	/*
	 * @Test
	 * Your new test
	 * https://junit.org/junit4/javadoc/latest/org/junit/Assert.html
	 * void new_test(){
	 * 	//test stuff
	 * }
	 */

	private Greeter g;
}
